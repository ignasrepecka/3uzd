#include "C:/Users/Administrator/source/repos/dldltrecias/dldl/dll.h"
using namespace std;

int main() {
    srand(time(0));

    int a;
    cout << "Ka pasirinksite?: 1 - Vidurkis, 2 - Mediana, 3 - Generuoti failus, 4 - Ivesti: ";
    cin >> a;

    vector<Studentas> studentai;


    try {
        if (a == 3) {
            int fileNum;
            cout << "Kiek failu norite generuoti?: ";
            cin >> fileNum;

            for (int i = 1; i <= fileNum; ++i) {
                int n;
                cout << "Kiek studentu bus " << i << "-ajame faile?: ";
                cin >> n;
                generateFile(n, i);
            }
        }
        else if (a == 1 || a == 2) {
            int fileNum;
            cout << "Kiek failu norite skaityti?: ";
            cin >> fileNum;
            cout << "--------------------------------------------------------------------------";
            cout << endl;
            for (int i = 1; i <= fileNum; ++i) {
                int n;
                cout << "Kiek studentu yra " << i << "-ajame faile?: ";
                cin >> n;
                string filename = "C:\\Users\\Administrator\\Desktop\\cc++++\\v3.0\\studentai" + to_string(n) + ".txt";

                isFailo(studentai, a, filename);

            }
        }
        else if (a == 4) {
            ivestiStudentus(a);
        }
    }
    catch (const exception& e) {
        cerr << "Klaida: " << e.what() << endl;
    }

    return 0;
}