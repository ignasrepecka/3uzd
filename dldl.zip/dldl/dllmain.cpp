﻿// dllmain.cpp : Defines the entry point for the DLL application.
#include "pch.h"
#include "dll.h"

using namespace std;

void Studentas::calculateStatistics() {
    double suma = 0;
    for (int j : this->getBalai()) {
        suma += j;
    }
    suma += this->getEgz(); // Include the exam grade in the sum

    std::vector<int> balaiCopy = this->getBalai();
    balaiCopy.push_back(this->getEgz()); // Include the exam grade in the grades vector
    sort(balaiCopy.begin(), balaiCopy.end());
    if ((balaiCopy.size()) % 2 == 0)
        this->mediana = (balaiCopy[balaiCopy.size() / 2 - 1] + balaiCopy[balaiCopy.size() / 2]) / 2.0;
    else
        this->mediana = balaiCopy[balaiCopy.size() / 2];

    this->vidurkis = suma / balaiCopy.size();
}


std::ostream& operator<<(std::ostream& os, const Studentas& s) {
    os << s.getVardas() << " " << s.getPavarde() << " " << s.getVidurkis();
    return os;
}

using namespace std;
using namespace std::chrono;  // Use the chrono namespace

void isFailo(std::vector<Studentas>& studentai, int a, const string& filename) {
    std::vector<Studentas> vargsiukai;
    std::vector<Studentas> kietiakai;
    studentai.clear();  // Clear the vector
    ifstream failas(filename);
    if (!failas.is_open()) {
        throw runtime_error("Nepavyko atidaryti failo");
    }

    // Skip the header line
    string header;
    getline(failas, header);

    string line;

    // Start timing
    auto start = high_resolution_clock::now();

    while (getline(failas, line)) {
        istringstream iss(line);
        Studentas studentas;
        studentas.readStudent(iss);
        studentas.calculateStatistics();
        studentai.push_back(studentas);
    }

    // Stop timing and calculate the duration
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);

    cout << "Duomenu nuskaitymas is failu";
    cout << endl;
    cout << "Trukme: "
        << duration.count() << " microseconds" << endl;

    failas.close();

    int Strat;
    std::cout << "Kokia Strategija naudoti?: 1 - Strategija1, 2 - Strategija2, 3 - Strategija3: ";
    std::cin >> Strat;

    int sortOption;
    std::cout << "Kaip norite rusiuoti studentus?: 1 - Pagal varda, 2 - Pagal pavarde, 3 - Pagal vidurki, 4 - Pagal mediana: ";
    std::cin >> sortOption;

    strat(studentai, a, Strat, sortOption, kietiakai, vargsiukai);

    // Start timing
    start = high_resolution_clock::now();

    int size = (Strat == 1) or (Strat == 3) ? studentai.size() : (studentai.size() + vargsiukai.size());

    // Write the students to files
    ofstream failas1("kietiakai" + to_string(size) + ".txt");
    ofstream failas2("vargsiukai" + to_string(size) + ".txt");

    vector<Studentas>& target = (Strat == 1) or (Strat == 3) ? kietiakai : studentai;

    for (const Studentas& studentas : target) {
        failas1 << studentas.getVardas() << "\t" << studentas.getPavarde() << "\t";
        if (a == 1) {
            failas1 << studentas.getVidurkis() << endl;
        }
        else if (a == 2) {
            failas1 << studentas.getMediana() << endl;
        }
    }
    for (const Studentas& studentas : vargsiukai) {
        failas2 << studentas.getVardas() << "\t" << studentas.getPavarde() << "\t";
        if (a == 1) {
            failas2 << studentas.getVidurkis() << endl;
        }
        else if (a == 2) {
            failas2 << studentas.getMediana() << endl;
        }
    }
    failas1.close();
    failas2.close();

    // Stop timing and calculate the duration
    stop = high_resolution_clock::now();
    duration = duration_cast<microseconds>(stop - start);

    cout << "Surusiuotu studentu isvedimas i 'kietiakai' ir 'vargsiukai'";
    cout << endl;
    cout << "Trukme: "
        << duration.count() << " microseconds" << endl;
    cout << "--------------------------------------------------------------------------";
    cout << endl;
}


void generateFile(int n, int fileNum) {
    string filename = "studentai" + to_string(n) + ".txt";
    ofstream failas(filename);
    if (!failas.is_open()) {
        cerr << "Nepavyko atidaryti failo" << endl;
        exit(1);
    }

    // Write the header
    failas << "Vardas\tPavarde\tND1\tND2\tEgz." << endl;

    for (int i = 1; i <= n; ++i) {
        failas << "Vardas" << i << "\tPavarde" << i;
        for (int j = 0; j < 2; ++j) {
            failas << "\t" << rand() % 10 + 1;
        }
        failas << "\t" << rand() % 10 + 1 << endl;  // Exam score
    }

    failas.close();
}

void ivestiStudentus(int a) {
    int n;
    cout << "Kiek studentu: ";
    cin >> n;

    vector<Studentas> studentai(n);

    for (int i = 0; i < n; ++i) {
        cout << "Irasyti studento duomenis (vardas, pavarde, balai, egz): " << endl;
        Studentas temp;
        cin >> temp;
        cout << endl;

        temp.calculateStatistics();

        Studentas newStudent(temp);

        studentai[i] = newStudent;
    }

    for (const auto& studentas : studentai) {
        cout << studentas << endl; // Use the overloaded output operator
    }
}

bool compareByName(const Studentas& a, const Studentas& b) {
    return a.getVardas() < b.getVardas();
}

bool compareBySurname(const Studentas& a, const Studentas& b) {
    return a.getPavarde() < b.getPavarde();
}

bool compareByAverage(const Studentas& a, const Studentas& b) {
    return a.getVidurkis() < b.getVidurkis();
}

bool compareByMedian(const Studentas& a, const Studentas& b) {
    return a.getMediana() < b.getMediana();
}

void sortStudents(std::vector<Studentas>& studentai, int sortOption) {
    switch (sortOption) {
    case 1:
        std::sort(studentai.begin(), studentai.end(), compareByName);  // To sort by name
        break;
    case 2:
        std::sort(studentai.begin(), studentai.end(), compareBySurname);  // To sort by surname
        break;
    case 3:
        std::sort(studentai.begin(), studentai.end(), compareByAverage);  // To sort by average
        break;
    case 4:
        std::sort(studentai.begin(), studentai.end(), compareByMedian);  // To sort by median
        break;
    default:
        std::cout << "Netinkamas rūšiavimo pasirinkimas. Prašome pasirinkti nuo 1 iki 4." << std::endl;
        break;
    }
}

void strat(std::vector<Studentas>& studentai, int a, int Strat, int sortOption, std::vector<Studentas>& kietiakai, std::vector<Studentas>& vargsiukai) {
    if (Strat == 1) {
        auto start = high_resolution_clock::now();
        for (const Studentas& studentas : studentai) {
            if (a == 1) {
                if (studentas.getVidurkis() >= 5) {
                    kietiakai.push_back(studentas);
                }
                else {
                    vargsiukai.push_back(studentas);
                }
            }
            else if (a == 2) {
                if (studentas.getMediana() >= 5) {
                    kietiakai.push_back(studentas);
                }
                else {
                    vargsiukai.push_back(studentas);
                }
            }
        }

        sortStudents(kietiakai, sortOption);
        sortStudents(vargsiukai, sortOption);

        auto stop = high_resolution_clock::now();
        auto duration = duration_cast<microseconds>(stop - start);

        std::cout << "Rusiavimas";
        std::cout << std::endl;
        std::cout << "Trukme: "
            << duration.count() << " microseconds" << std::endl;
    }
    else if (Strat == 2) {
        auto start = high_resolution_clock::now();
        studentai.erase(std::remove_if(studentai.begin(), studentai.end(), [&](const Studentas& studentas) {
            bool isVargsiukas = (a == 1 && studentas.getVidurkis() < 5) || (a == 2 && studentas.getMediana() < 5);
            if (isVargsiukas) {
                vargsiukai.push_back(studentas);
            }
            return isVargsiukas;
            }), studentai.end());

        sortStudents(studentai, sortOption);
        sortStudents(vargsiukai, sortOption);

        auto stop = high_resolution_clock::now();
        auto duration = duration_cast<microseconds>(stop - start);

        std::cout << "Rusiavimas";
        std::cout << std::endl;
        std::cout << "Trukme: "
            << duration.count() << " microseconds" << std::endl;

    }
    else {
        auto start = high_resolution_clock::now();
        auto it = std::partition(studentai.begin(), studentai.end(), [a](const Studentas& studentas) {
            if (a == 1) {
                return studentas.getVidurkis() >= 5;
            }
            else if (a == 2) {
                return studentas.getMediana() >= 5;
            }
            return false;
            });

        kietiakai.assign(studentai.begin(), it);
        vargsiukai.assign(it, studentai.end());

        sortStudents(kietiakai, sortOption);
        sortStudents(vargsiukai, sortOption);

        auto stop = high_resolution_clock::now();
        auto duration = duration_cast<microseconds>(stop - start);

        std::cout << "Rusiavimas";
        std::cout << std::endl;
        std::cout << "Trukme: "
            << duration.count() << " microseconds" << std::endl;
    }
}
