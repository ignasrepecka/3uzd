#pragma once
#ifndef _DLLH
#define _DLLH

#include <iostream>
#include <stdio.h>
#include <windows.h>

#ifdef DLL_EXPORTS
#define DLL_API __declspec(dllexport)
#else
#define DLL_API __declspec(dllimport)
#endif

#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <algorithm>
#include <stdexcept>
#include <fstream>
#include <sstream>
#include <random>
#include <chrono>
#include <list>
#include <istream>
#include <ostream>
#include <stdexcept>
#include <limits>
#include <cstdlib>
#include <iostream>



extern "C"

class Zmogus {
protected:
    std::string vardas;
    std::string pavarde;

public:
    // Constructor
    Zmogus() {}

    // Virtual Destructor
    virtual ~Zmogus() {}

    // Pure virtual function
    virtual void calculateStatistics() = 0;

    // Getters
    inline std::string getVardas() const { return vardas; }
    inline std::string getPavarde() const { return pavarde; }
};

extern "C"

class Studentas : public Zmogus {
private:
    std::vector<int> balai;
    double vidurkis;
    double mediana;
    int egz;

public:
    // Constructor
    Studentas() : vidurkis(0), mediana(0), egz(0) {}

    // Rule of Three
    // 1. Destructor
    ~Studentas() {
    }

    // 2. Copy constructor
    Studentas(const Studentas& other)
        : Zmogus(other), balai(other.balai),
        vidurkis(other.vidurkis), mediana(other.mediana), egz(other.egz) {}

    // 3. Copy assignment operator
    Studentas& operator=(const Studentas& other) {
        if (this != &other) {
            Zmogus::operator=(other);
            balai = other.balai;
            vidurkis = other.vidurkis;
            mediana = other.mediana;
            egz = other.egz;
        }
        return *this;
    }

    // Getters
    std::vector<int> getBalai() const { return balai; }
    double getVidurkis() const { return vidurkis; }
    double getMediana() const { return mediana; }
    int getEgz() const { return egz; }

    // Other member functions
    void calculateStatistics();

    // New method
    std::istream& readStudent(std::istream& is) {
        is >> this->vardas >> this->pavarde;
        for (int i = 0; i < 2; i++) {
            int j;
            is >> j;
            this->balai.push_back(j);
        }
        is >> this->egz;
        return is;
    }

    // Input/output operators
    friend std::istream& operator>>(std::istream& is, Studentas& s) {
        return s.readStudent(is);
    }

    friend std::ostream& operator<<(std::ostream& os, const Studentas& s);
};



extern "C"
DLL_API void generateFile(int n, int fileNum);
extern "C"
DLL_API void ivestiStudentus(int a);

extern "C"

DLL_API void isFailo(std::vector<Studentas>&studentai, int a);

extern "C"

DLL_API void strat(std::vector<Studentas>&studentai, int a, int Strat, int sortOption, std::vector<Studentas>&kietiakai, std::vector<Studentas>&vargsiukai);
extern "C"
DLL_API bool compareByName(const Studentas& a, const Studentas& b);
extern "C"
DLL_API bool compareBySurname(const Studentas& a, const Studentas& b);
extern "C"
DLL_API bool compareByAverage(const Studentas& a, const Studentas& b);
extern "C"
DLL_API bool compareByMedian(const Studentas& a, const Studentas& b);
extern "C"
DLL_API void sortStudents(std::vector<Studentas>& studentai, int sortOption);

DLL_API void isFailo(std::vector<Studentas>& studentai, int a, const std::string& filename);
#endif